"""
Configuration file
"""

BASE_URL = "http://localhost:8000/v0"
# BASE_URL = "https://phospho-backend-zxs3h5fuba-oc.a.run.app"
