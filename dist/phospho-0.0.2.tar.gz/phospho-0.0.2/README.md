# phospho

This is the repo of the phospho package.

## Requirements

- Python 3.8 or higher
- [Poetry](https://python-poetry.org/) for packaging and dependency management