"""
Configuration file
"""

BASE_URL = "https://phospho-backend-zxs3h5fuba-oc.a.run.app"