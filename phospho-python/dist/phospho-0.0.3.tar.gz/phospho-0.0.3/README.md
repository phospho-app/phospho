# phospho Python Library

The phospho package enables developper to easily wrap their code, so it can be deployed to phospho. Please note the project is still under development.

## Requirements

- Python 3.8 or higher

## Installation
Run the command below to install the package:

```bash
pip install --upgrade phospho
```

## Usage

See the [documentation](https://docs.phospho.app/) for more information.